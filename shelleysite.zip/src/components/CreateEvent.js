import React, { Component } from 'react'
import { Link } from 'react-router-dom'


class CreateEvent extends Component {

    handleSubmit(event) {

    }
    
    render() {

        return (
            <div className="create-event">
                <div className="app-header">
                    <h2>Create an Event</h2>
                </div>
                <div className="create-event-body">
                    <form onSubmit={this.handleSubmit.bind(this)}>
                        <p>Title:</p>
                        <input ref={(input) => {this.title = input}} required type="text"/>
                        <p>Description:</p>
                        <input ref={(input) => {this.description = input}} required type="text" />
                        <p>Location:</p>
                        <input ref={(input) => {this.location = input}} required type="text" />
                        <p>Date:</p>
                        <input ref={(input) => {this.date = input}} required type="datetime-local" />
                        <button type="submit">Submit!</button>
                    </form>
                </div>
            </div>
        )
    }
}

export default CreateEvent